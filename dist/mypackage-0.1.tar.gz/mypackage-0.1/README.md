# mypackage
This library was created for the purpose of having a go at publishing a python package.

# How to install